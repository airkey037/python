#importowanie modułów
from sys import version
from time import localtime
import login

#potrzebne zmienne
czas=localtime()
is_login=False

#funkcja tworząca menu
def menu(plik,zmiana):
	while True:
		print()
		print("Data: %s.%s.%sr." % (czas[2], czas[1], czas[0]))
		print("Witaj %s! Co chcesz zrobić?" % plik.open_username())
		print("1. Zmień nazwę użytkownika")
		print("2. Zmień hasło")
		print("3. Wyloguj")
		print()
		i = input(">> ")
		print()
		if i == "1":
			zmiana.username_change()
		elif i == "2":
			zmiana.passwd_change()
		elif i == "3":
			break
		else:
			print("Komenda nieznana!")

#funkcja logująca
def zaloguj(sprawdz):
	username = sprawdz.username_error()
	passwd = sprawdz.passwd_error()
	return login.check_login(username, passwd)

#obiekty
f = login.fileOpen("user.aklogin")
z = login.infoChange(f)
s = login.infoCheck(f)

#finalny program
is_login = zaloguj(s)
if is_login == True:
	menu(f, z)
