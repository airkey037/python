import pickle

class fileOpen:
	def __init__(self, nazwa_pliku):
		self.nazwa_pliku = nazwa_pliku

	def open_username(self):
		file=open(self.nazwa_pliku, "rb")
		username=pickle.load(file)["username"]
		file.close()
		return username

	def open_passwd(self):
		file=open(self.nazwa_pliku, "rb")
		passwd=pickle.load(file)["passwd"]
		file.close()
		return passwd

	def write_username(self, new_username):
		passwd = self.open_passwd()
		file=open(self.nazwa_pliku, "wb")
		pickle.dump({"username": new_username, "passwd": passwd}, file)
		file.close()

	def write_passwd(self, new_passwd):
		username = self.open_username()
		file=open(self.nazwa_pliku, "wb")
		pickle.dump({"username": username, "passwd": new_passwd}, file)
		file.close()

class infoCheck:
	def __init__(self, obiekt_pliku):
		self.obiekt_pliku = obiekt_pliku

	def check_username (self, in_username):
		if in_username == self.obiekt_pliku.open_username():
			return True
		else:
			return False

	def check_passwd (self, in_passwd):
		if in_passwd == self.obiekt_pliku.open_passwd():
			return True
		else:
			return False

	def username_error(self):
		username_input = input("Podaj nazwę użytkownika: ")
		username_right = self.check_username(username_input)
		while not username_right:
			print("Nazwa użytkownika jest niepoprawna.")
			username_input = input("Podaj nazwę użytkownika: ")
			username_right = self.check_username(username_input)
		return True

	def passwd_error(self):
		passwd_input = input("Podaj hasło: ")
		passwd_right = self.check_passwd(passwd_input)
		while not passwd_right:
			print("Hasło jest niepoprawne.")
			passwd_input = input("Podaj hasło: ")
			passwd_right = self.check_passwd(passwd_input)
		return True

class infoChange:
	def __init__(self, obiekt_pliku):
		self.obiekt_pliku = obiekt_pliku

	def username_change(self):
		username = self.obiekt_pliku.open_username()
		new_username = input("Wprowadź nową nazwę użytkownika: ")
		self.obiekt_pliku.write_username(new_username)
		print()
		print("Zmieniono nazwę użytkownika z %s na %s." % (username, new_username))

	def passwd_change(self):
		passwd = self.obiekt_pliku.open_passwd()
		old_passwd = input("Wprowadź stare hasło: ")
		passwd1 = input("Wprowadź nowe hasło: ")
		passwd2 = input("Wprowadź nowe hasło ponownie: ")
		if passwd != old_passwd:
			print("Stare hasło nie jest poprawne!")
		elif passwd1 != passwd2:
			print("Hasła nie są takie same!")
		else:
			self.obiekt_pliku.write_passwd(passwd1)
			print()
			print("Hasło zmienione z %s na %s." % (passwd, passwd1))

def check_login(username_true, passwd_true):
	return username_true and passwd_true

