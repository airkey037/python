#AKCode version 1.0.0
#by AirKey. All Rights Reserved
VERSION = "1.0.0"

global alfabet
global dlugosc_alfabetu
alfabet = "abcdefghijklmnopqrstuvwxyz"
dlugosc_alfabetu = len(alfabet)

def getAttributes(insertPassword, insertKey):
    haslo = input("%s: " % insertPassword)
    klucz = input("%s: " % insertKey)
    wlasciwosci = {
        "klucz": klucz,
        "haslo": haslo.lower()
    }
    return wlasciwosci

def version():
    print("       /\          |   /   |--------  |----------|  |---------\    |------------")
    print("      /  \         |  /    |          |          |  |          \   |")
    print("     /    \        | /     |          |          |  |           |  |")
    print("    /      \       |/      |          |          |  |           |  |------------")
    print("   /--------\      |\      |          |          |  |           |  |")
    print("  /          \     | \     |          |          |  |           |  |")
    print(" /            \    |  \    |          |          |  |           /  |")
    print("/              \   |   \   |--------  |----------|  |----------/   |------------")
    print()
    print("AKCode version %s by AirKey" % VERSION)


class code:
    def __init__(self, password, key):
        self.haslo = password
        self.klucz_nie = key
        self.klucz = None

    def transformKey(self):
        dlugosc_hasla = len(self.haslo)
        klucz_c = []
        klucz_a = []
        for x in self.klucz_nie:
            klucz_a.append(int(x))
    
        i = 0
        while i < dlugosc_hasla:
            for y in klucz_a:
                klucz_c.append(y)
                i += 1
                if i == dlugosc_hasla:
                    break
        
        self.klucz = klucz_c
        return True

    def coding_debug(self, password, key):
        translation = ""

        for symbol in password:
            symbolIndex = alfabet.find(symbol)

            if symbolIndex == -1:
                translation += symbol
            else:
                symbolIndex += key

                if symbolIndex >= dlugosc_alfabetu:
                    symbolIndex -= dlugosc_alfabetu
                elif symbolIndex < 0:
                    symbolIndex += dlugosc_alfabetu

                translation += alfabet[symbolIndex]

        return translation
    
    def uncoding_debug(self, password, key):
        klucz = -key
        translation = ""

        for symbol in password:
            symbolIndex = alfabet.find(symbol)

            if symbolIndex == -1:
                translation += symbol
            else:
                symbolIndex += klucz

                if symbolIndex >= dlugosc_alfabetu:
                    symbolIndex -= dlugosc_alfabetu
                elif symbolIndex < 0:
                    symbolIndex += dlugosc_alfabetu

                translation += alfabet[symbolIndex]

        return translation

class operations:
    def __init__(self, codeInfo):
        self.codeInfo = codeInfo
        self.haslo = self.codeInfo.haslo
        
    def coding(self):
        self.codeInfo.transformKey()
        klucz_c = self.codeInfo.klucz
        haslo = []
        for x in range(0, len(klucz_c)):
            aktualnyKlucz = klucz_c[x]
            aktualnaLitera = self.haslo[x]
            zaszyfrowanaLitera = self.codeInfo.coding_debug(aktualnaLitera, aktualnyKlucz)
            haslo.append(zaszyfrowanaLitera)
        
        return "".join(haslo)
    
    def uncoding(self):
        self.codeInfo.transformKey()
        klucz_c = self.codeInfo.klucz
        haslo = []
        for x in range(0, len(klucz_c)):
            aktualnyKlucz = klucz_c[x]
            aktualnaLitera = self.haslo[x]
            zaszyfrowanaLitera = self.codeInfo.uncoding_debug(aktualnaLitera, aktualnyKlucz)
            haslo.append(zaszyfrowanaLitera)
        
        return "".join(haslo)