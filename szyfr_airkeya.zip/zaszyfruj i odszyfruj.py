import akcode
informacje = akcode.getAttributes("Podaj, co chcesz zaszyfrować/odszyfrować", "Podaj klucz")
haslo = ""
oKodowaniu = akcode.code(key=informacje["klucz"], password=informacje["haslo"])
zakodujOdkoduj = akcode.operations(oKodowaniu)
print("Co chcesz zrobić?")
print("1. Zaszyfruj")
print("2. Odszyfruj")
print("3. Wersja pluginu AKCode")
zrob = int(input(">>> "))
if zrob == 1:
    haslo = zakodujOdkoduj.coding()
    print(haslo)
elif zrob == 2:
    haslo = zakodujOdkoduj.uncoding()
    print(haslo)
elif zrob == 3:
    akcode.version()